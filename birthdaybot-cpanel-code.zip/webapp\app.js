(() => {
  'use strict';
  const $=id=>document.getElementById(id),calendar=$('calendar'),input=$('date'),error=$('error'),save=$('save'),saveHint=$('save-hint');
  const telegram=window.Telegram&&window.Telegram.WebApp;
  if(telegram){telegram.ready();telegram.expand();}
  const today=new DateCalendars.todaySerial();
  let activeCalendar=calendar.value;
  const apiBase=String(window.BOT_API_URL||window.location.origin).replace(/\/+$/,'');
  const initData=telegram&&telegram.initData;
  const canSave=!!(initData||(telegram&&typeof telegram.sendData==='function'));
  save.disabled=!canSave;
  if(canSave)saveHint.textContent='سال برای بررسی تاریخ استفاده می‌شه و فقط ماه و روز ذخیره می‌شن.';
  function todayParts(){return DateCalendars.toCalendar(calendar.value,today);}
  function render(){
    error.hidden=true;save.disabled=!canSave;
    try{
      const result=DateCalendars.convert(calendar.value,input.value);
      $('persian-result').textContent=DateCalendars.formatDate(result.persian);
      $('gregorian-result').textContent=DateCalendars.formatDate(result.gregorian);
      $('hijri-result').textContent=DateCalendars.formatDate(result.hijri);
      $('distance').textContent=result.distance;
      const currentPersianYear=DateCalendars.toCalendar('persian',today).year;
      save.disabled=!canSave||result.persian.year>currentPersianYear;
      if(result.persian.year>currentPersianYear&&canSave)saveHint.textContent='سال تولد نمی‌تونه در آینده باشه.';
      else if(canSave)saveHint.textContent='سال فقط برای بررسی تاریخ استفاده می‌شه؛ بات ماه و روز رو نگه می‌داره.';
      save.dataset.persian=JSON.stringify(result.persian);
    }catch(e){
      for(const id of ['persian-result','gregorian-result','hijri-result'])$(id).textContent='—';
      $('distance').textContent='';error.textContent=e.message||'این تاریخ معتبر نیست.';error.hidden=false;
      save.dataset.persian='';save.disabled=true;
    }
  }
  calendar.addEventListener('change',()=>{try{const oldDate=DateCalendars.convert(activeCalendar,input.value);input.value=DateCalendars.formatDate(DateCalendars.toCalendar(calendar.value,oldDate.serial));}catch{}activeCalendar=calendar.value;render();});
  input.addEventListener('input',render);
  $('today').addEventListener('click',()=>{input.value=DateCalendars.formatDate(todayParts());render();});
  save.addEventListener('click',async()=>{
    if(!canSave)return;
    save.disabled=true;
    try{
      const p=JSON.parse(save.dataset.persian);
      if(initData){
        const response=await fetch(apiBase+'/api/birthday',{method:'POST',headers:{Authorization:`tma ${initData}`,'Content-Type':'application/json'},body:JSON.stringify({calendar:'solar_hijri',year:p.year,month:p.month,day:p.day})});
        const body=await response.json();
        if(!response.ok)throw new Error(body.error||'ثبت انجام نشد.');
        saveHint.textContent='تاریخ تولدت ذخیره شد.';
      }else{
        telegram.sendData(JSON.stringify({action:'save_birthday',calendar:'solar_hijri',year:p.year,month:p.month,day:p.day}));
      }
    }catch(error){saveHint.textContent=error.message||'ثبت انجام نشد. صفحه رو از داخل بات باز کن و دوباره تلاش کن.';save.disabled=false;}
  });
  input.value=DateCalendars.formatDate(todayParts());render();
})();
